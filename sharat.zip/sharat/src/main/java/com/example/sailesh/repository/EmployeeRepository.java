package com.example.sailesh.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.example.sailesh.model.Employee;

public interface EmployeeRepository extends JpaRepository<Employee, Long>{



  

}
