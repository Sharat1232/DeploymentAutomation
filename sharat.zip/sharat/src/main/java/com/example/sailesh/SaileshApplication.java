package com.example.sailesh;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SaileshApplication {

	public static void main(String[] args) {
		SpringApplication.run(SaileshApplication.class, args);
	}

}
