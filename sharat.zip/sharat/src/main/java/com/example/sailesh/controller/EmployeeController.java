package com.example.sailesh.controller;

import java.util.HashMap;
import java.util.Map;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.example.sailesh.model.Employee;
import com.example.sailesh.repository.EmployeeRepository;
import com.example.sailesh.service.EmployeeService;

import antlr.collections.List;

@RestController
@CrossOrigin(origins = "http://localhost:4200")
public class EmployeeController {

	@Autowired
	private EmployeeRepository employeeRepository;

	@Autowired
	private EmployeeService employeeService;

	public String myFirstController() {
		return "Hello World";
	}

	@PostMapping("/updateEmployee/{id}")
	public ResponseEntity<Employee> updateEmployee(@PathVariable(value = "id") Long employeeId,
			@Valid @RequestBody Employee employeeDetails) {

		
		Optional<Employee> employee = employeeRepository.findById(employeeId);
		Employee updatedEmployee = null;
		
		if(employee.isPresent())
		{
			Employee emp = employee.get();

			emp.setEmail(employeeDetails.getEmail());
			emp.setLname(employeeDetails.getLname());
			emp.setFname(employeeDetails.getFname());
			emp.setMobileno(employeeDetails.getMobileno());
			emp.setRole(employeeDetails.getRole());
			emp.setPassword(employeeDetails.getPassword());
			 updatedEmployee = employeeRepository.save(emp);
			 System.out.println("Employee no:"+employeeId +" updated.");
		}
		else {
			System.out.println("Employee no:"+employeeId +" not available.");
			return null;
		}

		
		return ResponseEntity.ok(updatedEmployee);
	}

	@DeleteMapping("/employees/{id}")
	public Map<String, Boolean> deleteEmployee(@PathVariable(value = "id") Long employeeId) {
		Employee employee = employeeService.getEmployeeById(employeeId);
		employeeRepository.delete(employee);
		Map<String, Boolean> response = new HashMap<>();
		response.put("deleted", Boolean.TRUE);
		return response;

	}

	@GetMapping("/employees")
	public java.util.List<Employee> getAllEmployee() {
		System.out.println("12345");
		return employeeRepository.findAll();
	}

	@PostMapping("/createEmployee")
	public Employee createEmployee(@RequestBody Employee employee) {
		return employeeRepository.save(employee);
	}

	@GetMapping("/employees/{id}")
	public Employee getEmployeeById(@PathVariable(value = "id") Long employeeId) {

		Employee employee = employeeService.getEmployeeById(employeeId);

		return employee;

	}
	
	@GetMapping("/searchemployees/email/{email}")
	public Employee getEmployeeByemail(@PathVariable(value = "email") String email) {

	Employee employee = employeeService.getEmployeeByEmail(email);
		return employee;

	}
}
