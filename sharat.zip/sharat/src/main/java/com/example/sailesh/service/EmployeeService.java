package com.example.sailesh.service;

import java.util.Map;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.sailesh.model.Employee;
import com.example.sailesh.repository.EmployeeRepository;

@Service
public class EmployeeService {
	
	
	@Autowired
	private EmployeeRepository employeeRepository;

	public Employee getEmployeeById(Long employeeId) {
		
		Optional<Employee> employee = employeeRepository.findById(employeeId);
		System.out.println("inside service");
		System.out.println(employee.get());
		
		return employee.get();
	}
	
	public Map<String, Boolean> deleteEmployee(Long employeeId){
		Optional<Employee> employee = employeeRepository.findById(employeeId);
		System.out.println("inside service");
		System.out.println(employee.get());
		
		return (Map<String, Boolean>) employee.get();
	}

}
