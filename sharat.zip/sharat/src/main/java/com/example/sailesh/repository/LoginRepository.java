package com.example.sailesh.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import com.example.sailesh.model.User;

public interface LoginRepository extends JpaRepository<User, Long> {
	
	@Query(value = "SELECT * FROM User u WHERE u.username = :userame and u.password = :password", nativeQuery = true)
	User userLogin(@Param("userame") String userName, @Param("password") String password);

}
