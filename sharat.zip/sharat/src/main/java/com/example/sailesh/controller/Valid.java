package com.example.sailesh.controller;

public @interface Valid {

}
