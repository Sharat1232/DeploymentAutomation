package com.example.sailesh.controller;

public class ResourceNotFoundException extends Exception {

}
